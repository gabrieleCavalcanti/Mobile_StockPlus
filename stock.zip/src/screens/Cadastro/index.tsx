import { View, Text } from "react-native";

export default function CadastroScreen() {
  return (
    <View>
      <Text>Tela Cadastro</Text>
    </View>
  );
}