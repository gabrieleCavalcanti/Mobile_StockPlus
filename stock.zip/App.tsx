import { NavigationContainer } from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";

import Home from "./src/screens/Home";
import ProdutosQtd from "./src/screens/ProdutosQtd";
import ProdutosVenc from "./src/screens/ProdutoVenc";
import Movimentacoes from "./src/screens/Movimentacoes";

export type RootStackParamList = {
  Home: undefined;
  ProdutosQtd: undefined;
  ProdutosVenc: undefined;
  Movimentacoes: undefined;
};

const Stack = createNativeStackNavigator<RootStackParamList>();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen
          name="Home"
          component={Home}
          options={{
            headerShown: false,
          }}
        />

        <Stack.Screen
          name="ProdutosQtd"
          component={ProdutosQtd}
        />

        <Stack.Screen
          name="ProdutosVenc"
          component={ProdutosVenc}
        />

        <Stack.Screen
          name="Movimentacoes"
          component={Movimentacoes}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
}